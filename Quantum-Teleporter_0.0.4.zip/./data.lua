-- presets Basicos do mods
require("graficos/style.lua")
require("data/soundMaker")
require("data/grupos")
require("data/recursos")

-- blocos e qeuipamentos
require("data/blocos/quantum-teleporter-equipment")
require("data/blocos/quantum-teleporter-portal-entidade")
