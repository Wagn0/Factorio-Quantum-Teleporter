-- presets Basicos do mods
require("graficos/style.lua")
require("soundMaker")
require("grupos")
require("recursos")

-- blocos e qeuipamentos
require("blocos.quantum-teleporter-equipment")
require("data.blocos.quantum-teleporter-portal-entidade")
