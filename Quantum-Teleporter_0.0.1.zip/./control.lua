require("control/gui/gui-maker")
require("control/functions")
-- require("control/teleport 1.0")
require("control/gui/teleport 2.0")
