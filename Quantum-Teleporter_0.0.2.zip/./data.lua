-- presets Basicos do mods
require("graficos/style.lua")
